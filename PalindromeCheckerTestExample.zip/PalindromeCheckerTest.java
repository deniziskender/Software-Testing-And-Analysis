import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.TestCase;

public class PalindromeCheckerTest extends TestCase {

	PalindromeChecker checker;
	
	public void testPalindrome() {
		assertTrue(checker.isPalindrome("mom"));
	}

	public void testNonePalindrome() {
		assertFalse(checker.isPalindrome("hajkdlhask"));
	}
	
	public void testLongPalindrome() {
		assertTrue(checker.isPalindrome("321mommom123"));
	}
	
	public void testEmptyPalindrome() {
		assertTrue(checker.isPalindrome(""));
	}
	
	public void testNullPalindrome() {
		assertFalse(checker.isPalindrome(null));
	}
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		checker = new PalindromeChecker();
	}

	public void testCaseSensitivePalindrome() {
		assertTrue(checker.isPalindrome("Mom"));
	}
}

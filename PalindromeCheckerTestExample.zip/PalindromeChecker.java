
public class PalindromeChecker {

	public boolean isPalindrome(String string) {
		return string != null
			&& string.equalsIgnoreCase(getReversedString(string));
	}
	
	public String getReversedString(String original) {
		StringBuffer buffer = new StringBuffer(original);
		return buffer.reverse().toString();
	}
}
